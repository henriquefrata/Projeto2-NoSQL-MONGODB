# Trabalho2_NoSql
Repositório referente ao trabalho 2 da disciplina NoSql utilizando MongoDB
